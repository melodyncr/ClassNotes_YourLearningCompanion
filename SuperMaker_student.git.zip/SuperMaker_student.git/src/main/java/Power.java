public interface Power {

  /**
   * @author Melody
   * @date 11.08.2023
   */
  int LIMIT  = 2;

  int DUPLICATE_POWER  = -1;
  int ALREADY_ACTIVE = -2;
  int ALREADY_DEACTIVATE = -3;
  int NEW_POWER = 0;
  int REPLACEMENT_POWER = 1;
  int POWER_ACTIVATED = 2;
  int POWER_DEACTIVATED = 3;

  String MAGNETO = "Erik Lehnsherr";
  String SUPERGIRL = "Kara Zor-El";

  double getRarity();


  int activate(Normie receiver);

  int deactivate(Normie receiver);
}
