public class PowerFlight extends PowerSuperStrength implements Power {

    /**
     * @author Melody
     * @date 11.08.2023
     */
//    activate()
//    If boolean flying is already true the message
//    {name} is already flying!
//    Is printed where {name} is the name field of the current object to the terminal and returns Power.ALREADY_ACTIVE
//
//    Otherwise sets the boolean flying to true and prints the message to the terminal
//    {name} is flying!
//    Where {name} is the name field of the current object and returns Power.POWER_ACTIVATED
//    deactivate()
//    If boolean flying is already false the message
//    {name} is already on the ground!
//    Is printed where {name} is the name field of the current object to the terminal and returns Power.ALREADY_DEACTIVATE
//
//    Otherwise set the boolean flying to false and prints the message to the terminal
//    {name} is on the ground!
//    Where {name} is the name field of the current object and returns Power.POWER_DEACTIVATED
//    Output of flightTest:

    private boolean flying = false;
    private String name; // Assuming you have a 'name' field in your class

    public PowerFlight() {
    }



    @Override
    public double getRarity() {
        return 30.0;
    }
    @Override
    public int activate(Normie receiver) {
        if (flying) {
            System.out.println(name + " is already flying!");
            return Power.ALREADY_ACTIVE;
        }

        flying = true;
        System.out.println(name + " is flying!");
        return Power.POWER_ACTIVATED;
    }

    @Override
    public int deactivate(Normie receiver) {
        if (!flying) {
            System.out.println(name + " is already on the ground!");
            return Power.ALREADY_DEACTIVATE;
        }

        flying = false;
        System.out.println(name + " is on the ground!");
        return Power.POWER_DEACTIVATED;
    }
}
