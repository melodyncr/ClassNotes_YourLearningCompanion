import java.util.Objects;

/**
 * @author Melody
 * @date 11.08.2023
 */

public class Normie {

     protected String name;
     private double strength;
     private double durability;
     private double agility;

    public Normie(String name, double strength, double durability, double agility) {
        this.name = name;
        this.agility = agility;
        this.durability = durability;
        this.strength = strength;
    }

    public Normie() {

    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName(String supergirl) {
        return name;
    }

    public double getStrength() {
        return strength;
    }


    public double getDurability() {
        return durability;
    }

    public void setDurability(double durability) {
        this.durability = durability;
    }

    public double getAgility() {
        return agility;
    }

    public void setAgility(double agility) {
        this.agility = agility;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Normie)) return false;
        Normie normie = (Normie) o;
        return Double.compare(getStrength(), normie.getStrength()) == 0 && Double.compare(getDurability(), normie.getDurability()) == 0 && Double.compare(getAgility(), normie.getAgility()) == 0 && Objects.equals(getName(Power.SUPERGIRL), normie.getName(Power.SUPERGIRL));
    }

    @Override
    public int hashCode() {
        return Objects.hash(getName(Power.SUPERGIRL), getStrength(), getDurability(), getAgility());
    }


    public void setStrength(double strength) {
        this.strength =  strength;
    }
}