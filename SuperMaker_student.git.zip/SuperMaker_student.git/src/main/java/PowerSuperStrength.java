public class PowerSuperStrength implements Power {

    public static final double STRENGTH_MULTIPLIER = 1.5;
    private double originalStrength = 0;

        @Override
        public double getRarity() {
            return 42.9;
        }
    @Override
    public int activate(Normie receiver) {
        if (originalStrength == 0) {
            originalStrength = receiver.getStrength();
        }

        double newStrength = receiver.getStrength() * STRENGTH_MULTIPLIER;
        receiver.setStrength(newStrength);

        System.out.println(receiver.getName(Power.SUPERGIRL) + " now has strength of " + newStrength);
        return Power.POWER_ACTIVATED;
    }


    @Override
    public int deactivate(Normie receiver) {
        if (originalStrength == 0) {
            System.out.println(receiver.getName(Power.SUPERGIRL) + " does not have super strength!");
            return Power.ALREADY_DEACTIVATE;
        }

        receiver.setStrength(originalStrength);
        System.out.println(receiver.getName(Power.SUPERGIRL) + " now has strength of " + originalStrength);
        return Power.POWER_DEACTIVATED;
    }
    }
