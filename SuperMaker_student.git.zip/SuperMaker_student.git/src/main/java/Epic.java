import java.util.List;


/**
 * @author Melody
 * @date 11.08.2023
 */

public class Epic extends Normie {
    private List<Power> powers;

    public Epic(List<Power> powers) {
        super();
        this.powers = powers;
    }
    public int activatePower(Normie r) {
        int sumActivation = 0;
        for (Power power : powers) {
            sumActivation += power.activate(r);
        }
        return sumActivation;
    }

    public int deactivatePower() {
        int sumDeactivation = 0;
        for (Power power : powers) {
            sumDeactivation += power.deactivate(r);
        }
        return sumDeactivation;
    }


    public String getName(String supergirl) {
        String name = new String();
        if (powers.contains(new PowerMagnetism())) {
            setName(Power.MAGNETO);
            return name;
        }

        if (powers.contains(new PowerFlight()) && powers.contains(new PowerMagnetism())) {
            setName(Power.SUPERGIRL);
            return name;
        }

        return name;
    }

    public int listPower() {
        for (Power power : powers) {
            System.out.println(power.toString());
        }
        return powers.size();
    }

    public int mutate(Power magnetism) {
        return 0;
    }
}
