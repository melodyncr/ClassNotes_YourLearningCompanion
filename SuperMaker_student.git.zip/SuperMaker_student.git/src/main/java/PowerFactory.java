import java.util.ArrayList;
import java.util.List;

/**
 * @author Melody
 * @date 11.08.2023
 */
public abstract class PowerFactory {

  public static final String FLIGHT = "powerFlight";
  public static final String MAGNETISM = "powerMagnetism";
  public static final String SUPER_STRENGTH = "powerSuperStrength";

  public static List<Power> ALL_POWERS = new ArrayList<>();

  public static void addPower(PowerSuperStrength powerFlight) {
  }

  public static Power getRandomPower() {
      return null;
  }


  public static Power getPower(String magnetism) {

      return null;
  }


}
