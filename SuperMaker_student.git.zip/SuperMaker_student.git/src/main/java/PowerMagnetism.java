public class PowerMagnetism extends PowerSuperStrength implements Power{
    /**
     * @author Melody
     * @date 11.08.2023
     */

    private boolean magnetic = false;

    @Override
    public double getRarity() {
        return 20.5;
    }

    @Override
    public int activate(Normie receiver) {
        if (magnetic) {
            System.out.println("Erik Lehnsherr is already magnetic!");
            return Power.ALREADY_ACTIVE;
        }

        magnetic = true;
        System.out.println("Erik Lehnsherr is magnetic!");
        return Power.POWER_ACTIVATED;
    }

    @Override
    public int deactivate(Normie receiver) {
        if (!magnetic) {
            System.out.println("Erik Lehnsherr is not magnetic!");
            return Power.ALREADY_DEACTIVATE;
        }

        magnetic = false;
        System.out.println("Erik Lehnsherr is not magnetic!");
        return Power.POWER_DEACTIVATED;
    }
}
